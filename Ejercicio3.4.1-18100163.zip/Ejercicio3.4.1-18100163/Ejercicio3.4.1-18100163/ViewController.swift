//
//  ViewController.swift
//  Ejercicio3.4.1-18100163
//
//  Created by MAC 5 on 22/03/22.
//  Copyright © 2022 TecNM. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtAlto: UITextField!
    @IBOutlet weak var txtAncho: UITextField!
    @IBOutlet weak var txtX: UITextField!
    @IBOutlet weak var txtY: UITextField!
    @IBOutlet weak var lblA: UILabel!
    @IBOutlet weak var lblB: UILabel!
    @IBOutlet weak var lblResultado: UILabel!
    @IBOutlet weak var btnCalcularPerimetro: UIButton!
    @IBOutlet weak var btnCalcularArea: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func CalcularPerimetro(_ sender: Any) {
        let alto = Double(txtAlto.text!);
        let ancho = Double(txtAncho.text!);
        let x = Double(txtX.text!);
        let y = Double(txtY.text!);
        let figura = Figura(alto!,ancho!,x!,y!);
        //figura.alto = Double(txtAlto.text!);
        //figura.ancho = Double(txtAncho.text!);
        //figura.x = Double(txtX.text!);
        //figura.y = Double(txtY.text!);
        lblA.text = "A: \(figura.a)";
        lblB.text = "B: \(figura.b)"
        lblResultado.text = "Perimetro: \(figura.CalcularPerimetro())"
    }
    
    @IBAction func CalcularArea(_ sender: Any) {
        let alto = Double(txtAlto.text!);
        let ancho = Double(txtAncho.text!);
        let x = Double(txtX.text!);
        let y = Double(txtY.text!);
        let figura = Figura(alto!,ancho!,x!,y!);
        //figura.alto = Double(txtAlto.text!);
        //figura.ancho = Double(txtAncho.text!);
        //figura.x = Double(txtX.text!);
        //figura.y = Double(txtY.text!);
        lblA.text = "A: \(figura.a)";
        lblB.text = "B: \(figura.b)";
        lblResultado.text = "Area: \(figura.CalcularArea())"
    }
}

