//
//  Figura.swift
//  Ejercicio 3.4.2_18100163
//
//  Created by user217478 on 4/6/22.
//

import Foundation

protocol Figura{
    func calcularPerimetro() -> Double
    func calcularArea() -> Double
    func calcularVolumen() -> Double
}
