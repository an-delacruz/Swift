//
//  FiguraL.swift
//  Ejercicio3.4.1-18100163
//
//  Created by MAC 5 on 22/03/22.
//  Copyright © 2022 TecNM. All rights reserved.
//

import Foundation
class Figura {
    var alto:Double!
    var ancho: Double!
    var x:Double!
    var y:Double!
    var a:Double{
        get{
            return(self.ancho - self.x)
        }
    }
    var b:Double{
        get{
            return(self.alto - self.y)
        }
    }
    
    init(_ Alto:Double, _ Ancho:Double, _ x:Double, _ y:Double) {
        self.alto = Alto
        self.ancho = Ancho
        self.x = x;
        self.y = y;
    }
    func CalcularPerimetro() -> Double{
        let p1 = self.alto + self.x;
        let p2 = self.alto - self.y
        let p3 = self.ancho - self.x;
        let p4 = self.y + self.ancho;
        let res = p1 + p2 + p3 + p4;
        return (res)
    }
    func CalcularArea() -> Double{
        return (self.alto * self.x) + ((self.ancho - self.x) * self.y)
    }
}
